// CAPTURAR PELICULAS.JSON //

fetch("Peliculas.json")
.then(respuesta => respuesta.json())
.then(data => mostrarDatos(data))
.catch(error => console.log(error))

// IMPRIMIR IMAGENES EN HTML //

var mostrarDatos= function (data){
console.log(data)
var cards = [];
var like = "https://cdn-icons-png.flaticon.com/512/1820/1820042.png"
var dislike = "https://cdn-icons.flaticon.com/png/512/2839/premium/2839157.png?token=exp=1637161746~hmac=3ad957763d866ad40cc09c43c8b2c5a2"
for (let i = 0; i < data.length; i++) {
    cartas = data[i];
    cards+= `<div class="cartas" id="cartas" style="background-image:url(${cartas.poster})">
                <div class="infoCartas">
                    <span>
                        <img src="${like}" width="30px"></img>
                        <img style="opacity:0.5" width="30px"src="${dislike}"></img>
                    </span>
                    <h2> ${cartas.nombre}</h2>${cartas.calificacion}
                </div>
             </div>`
}
document.getElementById('contenedor-cartas').innerHTML = cards;


    var btn = document.getElementById('cartas');
    var informacion = document.getElementById('contenedorInformacion');
    var cerrar = document.getElementById('close');


    btn.addEventListener('click',()=>{
        informacion.classList.add('aparecer');
        document.body.addEventListener("keydown", function (escape){
        if (escape.keyCode === 27) {
        informacion.classList.remove('aparecer')
    }
    });
    })
    cerrar.addEventListener('click',()=>{
        informacion.classList.remove('aparecer')
    })

    var visualizarComentarios= [];
    var enviar = document.getElementById('btnEnviar')
    var imprimir = document.querySelector('.imprimir')
    enviar.addEventListener('click', ()=>{
        var texarea = document.getElementById('areaTexto').value;
        visualizarComentarios += `<p>${'comentado por: '+ localStorage.getItem('usuario')+'<br>'+texarea +' a la fecha '+ Date ()} <hr> </p>`;
        imprimir.innerHTML = visualizarComentarios;
    })


// ORDENAR POR NOMBRE // 
function ordenarNombre(){
    data.sort(function(ant, sig){ //comparando el campo nombre
        if (ant.nombre > sig.nombre){
            return 1;
        }
        if (ant.nombre < sig.nombre) {
            return -1;
        } 
        return 0;
    } );
    mostrarDatos(data)
};
  var ordenar=document.getElementById('ordenar');
  ordenar.addEventListener('click',ordenarNombre);

// FILTRO BARRA DE BUSQUEDA //
  function buscarPelicula(remover){
    var buscador = document.getElementById("buscador").value;
    var listaFiltrada = data.filter(palabra => palabra.nombre.toLowerCase().indexOf(buscador.toLowerCase()) > -1);
    console.log(listaFiltrada);
     mostrarDatos(listaFiltrada);
   
};
buscador.addEventListener("keyup", buscarPelicula);

}

// USUARIOS LOGIN //

var boton = document.getElementById("registrarse")

boton.addEventListener("click",function(){
    usuarioAgus=["agustinacuna","agustin1","https://randomuser.me/api/portraits/men/30.jpg"]
    usuarioJuana=["juanacuna","juana1","https://randomuser.me/api/portraits/women/68.jpg"]
    usuarioPedro=["pedroacuna","pedro1","https://randomuser.me/api/portraits/men/31.jpg"]
    error = document.getElementById('error')
    inputUsuario = document.getElementById('Email').value;
    inputPassword = document.getElementById('password').value;

    if (inputUsuario == usuarioAgus[0] && inputPassword == usuarioAgus[1]){
        location.replace("PaginaPrincipal.html")
        localStorage.setItem("usuario",inputUsuario+`<img src="${usuarioAgus[2]}" width="50px" height="50px" alt="" style="vertical-align: middle;margin-left:10px;border-radius:50%;">`)
}else if(inputUsuario==usuarioJuana[0] && inputPassword==usuarioJuana[1]){
    location.replace("PaginaPrincipal.html")
    localStorage.setItem("usuario",inputUsuario+`<img src="${usuarioJuana[2]}" width="50px" height="50px" alt="" style="vertical-align: middle;margin-left:10px;border-radius:50%;">`)
}else if(inputUsuario==usuarioPedro[0] && inputPassword==usuarioPedro[1]){
    location.replace("PaginaPrincipal.html")
    localStorage.setItem("usuario",inputUsuario+`<img src="${usuarioPedro[2]}" width="50px" height="50px" alt="" style="vertical-align: middle;margin-left:10px;border-radius: 50%;">`)
}
else{
    error.classList.add('aparecerError');
    setTimeout(() => {
        error.classList.remove('aparecerError')
    }, 4000);
}
})

// PULSAR TECLA PARA REMOVER ADVERTENCIA DE ERROR EN CONTRASEÑA//
function tecla(){
    error.classList.remove('aparecerError')
}




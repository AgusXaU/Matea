fetch("Peliculas.json")
.then(respuesta => respuesta.json())
.then(data => mostrarDatos(data))
.catch(error => console.log(error))



var mostrarDatos= function (data){
console.log(data)
var cards = [];
for (let i = 0; i < data.length; i++) {
    cartas = data[i];
    cards+= `<div class="cartas">
    <img src="${cartas.poster}" alt="">
    ${cartas.calificacion} 
</div>`
    // var nombre = estudiantes.nombre;
    // console.log(nombre)
}
document.getElementById('contenedor-cartas').innerHTML = cards;


var btn = document.querySelectorAll('img');
    var informacion = document.getElementById('contenedorInformacion');
    var cerrar = document.getElementById('close');

 console.log(btn)
    btn[5].addEventListener('click',()=>{
        informacion.classList.add('aparecer');
        document.body.addEventListener("keydown", function (escape){
        if (escape.keyCode === 27) {
        informacion.classList.remove('aparecer')
    }
    });
    })
    cerrar.addEventListener('click',()=>{
        informacion.classList.remove('aparecer')
    })

    var visualizarComentarios= [];
    var enviar = document.getElementById('btnEnviar')
    var imprimir = document.querySelector('.imprimir')
    enviar.addEventListener('click', ()=>{
        var texarea = document.getElementById('areaTexto').value;
        visualizarComentarios += `<p>${'comentado por: '+ localStorage.getItem('usuario')+'<br>'+texarea +' a la fecha '+ Date ()} <hr> </p>`;
        imprimir.innerHTML = visualizarComentarios;
    })


// ORDENAR POR NOMBRE // 
function ordenarNombre(){
    data.sort(function(ant, sig){ //comparando el campo nombre
        if (ant.nombre > sig.nombre){
            return 1;
        }
        if (ant.nombre < sig.nombre) {
            return -1;
        } 
        return 0;
    } );
    mostrarDatos(data)
};
  var ordenar=document.getElementById('ordenar');
  ordenar.addEventListener('click',ordenarNombre);






  function buscarPelicula(){
    var buscador = document.getElementById("buscador").value;
    var listaFiltrada = data.filter(palabra => palabra.nombre.toLowerCase().indexOf(buscador.toLowerCase()) > -1);
    console.log(listaFiltrada);
     
   mostrarDatos(listaFiltrada);

};
buscador.addEventListener("keyup", buscarPelicula);


}

var boton = document.getElementById("registrarse")

boton.addEventListener("click",function(){
    usuarioAgus=["agustinacuna","agustin1","https://randomuser.me/api/portraits/women/68.jpg"]
    usuarioJuan=["juanacuna","juan1"]
    usuarioPedro=["pedroacuna","pedro1"]
    error = document.getElementById('error')
    inputUsuario = document.getElementById('Email').value;
    inputPassword = document.getElementById('password').value;

if (inputUsuario == usuarioAgus[0] && inputPassword == usuarioAgus[1] || inputUsuario==usuarioJuan[0] && inputPassword==usuarioJuan[1]||inputUsuario==usuarioPedro[0] && inputPassword==usuarioPedro[1] ) {
    location.replace("Home.html")
}
else{
    error.classList.add('aparecerError');
    setTimeout(() => {
        error.classList.remove('aparecerError')
    }, 4000);
}

localStorage.setItem("usuario",inputUsuario);

})
function tecla(){
    error.classList.remove('aparecerError')
}



